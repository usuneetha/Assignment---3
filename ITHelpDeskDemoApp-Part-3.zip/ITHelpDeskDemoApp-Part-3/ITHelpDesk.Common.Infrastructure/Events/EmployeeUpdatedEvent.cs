﻿using Microsoft.Practices.Prism.Events;

namespace ITHelpDesk.Common.Infrastructure.Events
{
    public class EmployeeUpdatedEvent : CompositePresentationEvent<int> { }

}
